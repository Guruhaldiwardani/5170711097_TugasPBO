package manusiaaa;

public class ibu extends ayah {
 void penyayang(){
     System.out.println("ibu rumah tangga");
     System.out.println("selalu mengutamakan keluarga");
 }  
 void hoby(){
     System.out.println("memasak");
     System.out.println("senam");
 }
}
