package manusiaaa;

public class ayah {
void pekerja (){
    System.out.println("berwibawa");
    System.out.println("sayang anak");
}  
void olahraga (){
    System.out.println("bulutangkis");
    System.out.println("sepak bola");
}
}
