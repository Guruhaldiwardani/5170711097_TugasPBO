
package manusiaaa;

public class anak extends ayah {
void tugas(){
    System.out.println("sekolah");
    System.out.println("berbakti kepada orang tua ");
}
void lakiLaki(){
    System.out.println("sedikit nakal");
    System.out.println("jati diri");
}
 void perempuan(){
     System.out.println("rajin belajar");
     System.out.println("manja");
 }       
}
