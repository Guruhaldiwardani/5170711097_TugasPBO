
package manusiaaa;

public class Manusiaaa {

  public static void main(String[] args) {
   ayah setia = new ayah();
   ibu penyayang = new ibu();
   anak berbakti = new anak();
           
   setia.pekerja(); 
   setia.olahraga();
   penyayang.penyayang();
   penyayang.hoby();
   berbakti.tugas();
   berbakti.lakiLaki();
   berbakti.perempuan();
           
    }
    
}
